"use client";

import Link from "next/link";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function LoginPage() {
  return (
    <Suspense fallback={<LoginShell />}>
      <LoginPageContent />
    </Suspense>
  );
}

function LoginPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const callbackError = searchParams.get("error");
  const cancelled = searchParams.get("cancelled") === "1";

  async function handleLogin(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await fetch("/api/auth/quicksdk/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          password,
        }),
      });

      const payload = (await response.json()) as {
        error?: string;
        profileUrl?: string;
      };

      if (!response.ok) {
        setMessage(payload.error || "登录失败。");
        return;
      }

      router.push(payload.profileUrl || "/profile");
      router.refresh();
    } catch {
      setMessage("当前无法连接登录服务。");
    } finally {
      setLoading(false);
    }
  }

  return (
    <LoginShell>
      <form onSubmit={handleLogin} className="glow-purple" style={formStyle}>
        <h1 style={titleStyle}>账号登录</h1>

        <p style={subtitleStyle}>
          使用账号密码直接登录，或通过网页授权方式完成登录。
        </p>

        <div style={featureGridStyle}>
          <div style={featureCardStyle}>
            <div style={featureEyebrowStyle}>方式一</div>
            <strong style={featureTitleStyle}>账号密码</strong>
            <span style={featureTextStyle}>使用已创建的账号直接进入平台。</span>
          </div>
          <div style={featureCardStyle}>
            <div style={featureEyebrowStyle}>方式二</div>
            <strong style={featureTitleStyle}>网页授权登录</strong>
            <span style={featureTextStyle}>如需通过网页授权完成登录，可跳转到授权页面。</span>
          </div>
        </div>

        <input
          type="text"
          placeholder="账号"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          style={inputStyle}
          autoComplete="username"
        />

        <input
          type="password"
          placeholder="密码"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={inputStyle}
          autoComplete="current-password"
        />

        <button type="submit" disabled={loading} className="glow-purple-strong" style={buttonStyle}>
          {loading ? "登录中..." : "登录"}
        </button>

        <Link href="/auth/sdk/start" style={sdkButtonStyle}>
          打开网页登录页
        </Link>

        <div style={footerTextStyle}>
          还没有账号？{" "}
          <Link href="/signup" style={footerLinkStyle}>
            去注册
          </Link>
        </div>

        {cancelled ? <p style={infoStyle}>已取消网页登录。</p> : null}

        {callbackError ? (
          <p style={errorStyle}>{callbackError}</p>
        ) : message ? (
          <p style={errorStyle}>{message}</p>
        ) : null}
      </form>
    </LoginShell>
  );
}

function LoginShell({ children }: { children?: React.ReactNode }) {
  return (
    <main style={pageStyle}>
      <div className="auth-bg" />
      <div className="auth-overlay" />
      {children ?? <div style={fallbackPanelStyle} />}
    </main>
  );
}

const pageStyle: React.CSSProperties = {
  minHeight: "calc(100vh - 81px)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  position: "relative",
  margin: "-40px",
  width: "calc(100% + 80px)",
  overflow: "hidden",
  backgroundColor: "#07070a",
};

const formStyle: React.CSSProperties = {
  position: "relative",
  zIndex: 1,
  width: "100%",
  maxWidth: "480px",
  padding: "32px",
  borderRadius: "22px",
  background: "rgba(16,16,24,0.82)",
  border: "1px solid rgba(255,255,255,0.08)",
  boxShadow: "0 20px 40px rgba(0,0,0,0.35)",
  backdropFilter: "blur(14px)",
  display: "grid",
  gap: "12px",
};

const fallbackPanelStyle: React.CSSProperties = {
  ...formStyle,
  minHeight: "520px",
  opacity: 0.4,
};

const titleStyle: React.CSSProperties = {
  marginTop: 0,
  marginBottom: "2px",
  fontSize: "32px",
  color: "white",
  textAlign: "center",
};

const subtitleStyle: React.CSSProperties = {
  marginTop: 0,
  marginBottom: "8px",
  textAlign: "center",
  color: "#b8b8c5",
  fontSize: "14px",
  lineHeight: 1.6,
};

const featureGridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "10px",
  marginBottom: "4px",
};

const featureCardStyle: React.CSSProperties = {
  padding: "14px",
  borderRadius: "14px",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.06)",
  display: "grid",
  gap: "4px",
};

const featureEyebrowStyle: React.CSSProperties = {
  color: "#c4b5fd",
  fontSize: "11px",
  letterSpacing: "0.08em",
  textTransform: "uppercase",
};

const featureTitleStyle: React.CSSProperties = {
  color: "white",
  fontSize: "14px",
};

const featureTextStyle: React.CSSProperties = {
  color: "#a1a1aa",
  fontSize: "12px",
  lineHeight: 1.5,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "14px 16px",
  borderRadius: "12px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "rgba(0,0,0,0.28)",
  color: "white",
  boxSizing: "border-box",
  outline: "none",
  fontSize: "15px",
};

const buttonStyle: React.CSSProperties = {
  width: "100%",
  marginTop: "4px",
  padding: "14px 16px",
  borderRadius: "12px",
  border: "none",
  background: "linear-gradient(90deg, #7c3aed, #a855f7)",
  color: "white",
  fontWeight: 700,
  cursor: "pointer",
  fontSize: "15px",
};

const sdkButtonStyle: React.CSSProperties = {
  display: "block",
  width: "100%",
  boxSizing: "border-box",
  textAlign: "center",
  textDecoration: "none",
  padding: "14px 16px",
  borderRadius: "12px",
  border: "1px solid rgba(192,132,252,0.35)",
  background: "linear-gradient(180deg, rgba(124,58,237,0.18) 0%, rgba(76,29,149,0.28) 100%)",
  color: "white",
  fontWeight: 700,
  fontSize: "15px",
};

const footerTextStyle: React.CSSProperties = {
  marginTop: "4px",
  textAlign: "center",
  color: "#c4b5fd",
  fontSize: "14px",
};

const footerLinkStyle: React.CSSProperties = {
  color: "#ffffff",
  textDecoration: "none",
  fontWeight: 700,
};

const infoStyle: React.CSSProperties = {
  color: "#c4b5fd",
  textAlign: "center",
  fontSize: "14px",
  margin: 0,
};

const errorStyle: React.CSSProperties = {
  color: "#fca5a5",
  textAlign: "center",
  fontSize: "14px",
  margin: 0,
  lineHeight: 1.6,
};
