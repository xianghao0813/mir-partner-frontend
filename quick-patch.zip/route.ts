import { NextResponse } from "next/server";
import {
  getQuickSdkPublicBaseUrl,
} from "@/lib/quicksdk";
import { verifyAndSignInQuickSdkUser } from "@/lib/quicksdkAuth";

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const publicBaseUrl = getQuickSdkPublicBaseUrl(requestUrl.origin);
  const uid = requestUrl.searchParams.get("uid")?.trim() ?? "";
  const username = requestUrl.searchParams.get("username")?.trim() ?? "";
  const authToken = requestUrl.searchParams.get("authToken")?.trim() ?? "";
  const timeLeft = requestUrl.searchParams.get("timeLeft")?.trim() ?? "";

  if (!uid || !authToken) {
    return redirectWithError(requestUrl, "登录回调缺少必要参数。");
  }

  try {
    await verifyAndSignInQuickSdkUser({
      uid,
      username,
      authToken,
      timeLeft:
        timeLeft ? Number.parseInt(timeLeft, 10) : null,
    });

    return NextResponse.redirect(new URL("/profile", publicBaseUrl));
  } catch (error) {
    return redirectWithError(
      requestUrl,
      error instanceof Error ? error.message : "登录失败。"
    );
  }
}

function redirectWithError(requestUrl: URL, message: string) {
  const errorUrl = new URL("/login", requestUrl.origin);
  errorUrl.searchParams.set("error", message);
  return NextResponse.redirect(errorUrl);
}
